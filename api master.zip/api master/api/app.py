from flask import Flask, request, jsonify
from sklearn.externals import joblib
import pandas as pd
import numpy as np
import traceback
import json


app = Flask(__name__)



@app.route('/predict', methods=['GET','POST'])
def predict():
	if clf:
			try:
				obj = request.json
				print("Type of dict_obj", type(obj))
				#string = json.dumps(obj,  indent=4)
				#rex = json.loads(string)
				#print("Type of dict_obj", type(rex))
				print(obj)
					
				query = pd.get_dummies(pd.DataFrame(obj))
				print(query)
				query = query.reindex(columns=model_columns, fill_value=0)
				prediction = clf.predict(np.array(query))
				print(prediction)
					
				
				return jsonify([{'prediction':prediction}])
					
			except:
				return jsonify({'trace':traceback.format_exc()})
			
	else:
			print('Train the model first')
			return('No model here to use')
		
		
if __name__ == '__main__':	
	clf = joblib.load("nn_model.pkl")
	print('Model loaded')
	model_columns = joblib.load("model_columns.pkl")
	print('Model columns loaded')
	app.run(port=12334 , debug=True)
