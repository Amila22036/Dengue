import requests
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import json
from decimal import Decimal
from dateutil.parser import parse


response = {
  "Headline": {
    "EffectiveDate": "2019-08-28T19:00:00+05:30",
    "EffectiveEpochDate": 1566999000,
    "Severity": 4,
    "Text": "Expect showery weather Wednesday evening through Friday morning",
    "Category": "rain",
    "EndDate": "2019-08-30T13:00:00+05:30",
    "EndEpochDate": 1567150200,
    "MobileLink": "http://m.accuweather.com/en/lk/colombo/311399/extended-weather-forecast/311399?unit=c&lang=en-us",
    "Link": "http://www.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?unit=c&lang=en-us"
  },
  "DailyForecasts": [
    {
      "Date": "2019-08-27T07:00:00+05:30",
      "EpochDate": 1566869400,
      "Sun": {
        "Rise": "2019-08-27T06:04:00+05:30",
        "EpochRise": 1566866040,
        "Set": "2019-08-27T18:20:00+05:30",
        "EpochSet": 1566910200
      },
      "Moon": {
        "Rise": "2019-08-27T02:41:00+05:30",
        "EpochRise": 1566853860,
        "Set": "2019-08-27T15:34:00+05:30",
        "EpochSet": 1566900240,
        "Phase": "WaningCrescent",
        "Age": 26
      },
      "Temperature": {
        "Minimum": {
          "Value": 25.5,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 30.4,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperature": {
        "Minimum": {
          "Value": 28,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 36.5,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperatureShade": {
        "Minimum": {
          "Value": 28,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 33.8,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "HoursOfSun": 2.7,
      "DegreeDaySummary": {
        "Heating": {
          "Value": 0,
          "Unit": "C",
          "UnitType": 17
        },
        "Cooling": {
          "Value": 10,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "AirAndPollen": [
        {
          "Name": "AirQuality",
          "Value": 0,
          "Category": "Good",
          "CategoryValue": 1,
          "Type": "Particle Pollution"
        },
        {
          "Name": "Grass",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Mold",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Ragweed",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Tree",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "UVIndex",
          "Value": 7,
          "Category": "High",
          "CategoryValue": 3
        }
      ],
      "Day": {
        "Icon": 12,
        "IconPhrase": "Showers",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Moderate",
        "ShortPhrase": "Mostly cloudy",
        "LongPhrase": "Mostly cloudy",
        "PrecipitationProbability": 59,
        "ThunderstormProbability": 25,
        "RainProbability": 59,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 14.8,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 229,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 42.6,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 238,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "TotalLiquid": {
          "Value": 2,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 2,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 1,
        "HoursOfRain": 1,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 87
      },
      "Night": {
        "Icon": 12,
        "IconPhrase": "Showers",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Moderate",
        "ShortPhrase": "Rather cloudy, late showers",
        "LongPhrase": "Mostly cloudy, late-night showers",
        "PrecipitationProbability": 100,
        "ThunderstormProbability": 29,
        "RainProbability": 100,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 11.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 203,
            "Localized": "SSW",
            "English": "SSW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 20.4,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 219,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "TotalLiquid": {
          "Value": 7.8,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 7.8,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 4,
        "HoursOfRain": 4,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 80
      },
      "Sources": [
        "AccuWeather"
      ],
      "MobileLink": "http://m.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=1&unit=c&lang=en-us",
      "Link": "http://www.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=1&unit=c&lang=en-us"
    },
    {
      "Date": "2019-08-28T07:00:00+05:30",
      "EpochDate": 1566955800,
      "Sun": {
        "Rise": "2019-08-28T06:04:00+05:30",
        "EpochRise": 1566952440,
        "Set": "2019-08-28T18:20:00+05:30",
        "EpochSet": 1566996600
      },
      "Moon": {
        "Rise": "2019-08-28T03:42:00+05:30",
        "EpochRise": 1566943920,
        "Set": "2019-08-28T16:34:00+05:30",
        "EpochSet": 1566990240,
        "Phase": "WaningCrescent",
        "Age": 27
      },
      "Temperature": {
        "Minimum": {
          "Value": 25.1,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 29.2,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperature": {
        "Minimum": {
          "Value": 26.9,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 34.8,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperatureShade": {
        "Minimum": {
          "Value": 26.9,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 33,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "HoursOfSun": 2.4,
      "DegreeDaySummary": {
        "Heating": {
          "Value": 0,
          "Unit": "C",
          "UnitType": 17
        },
        "Cooling": {
          "Value": 9,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "AirAndPollen": [
        {
          "Name": "AirQuality",
          "Value": 0,
          "Category": "Good",
          "CategoryValue": 1,
          "Type": "Ozone"
        },
        {
          "Name": "Grass",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Mold",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Ragweed",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Tree",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "UVIndex",
          "Value": 6,
          "Category": "High",
          "CategoryValue": 3
        }
      ],
      "Day": {
        "Icon": 15,
        "IconPhrase": "Thunderstorms",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Light",
        "ShortPhrase": "An a.m. thunderstorm or two",
        "LongPhrase": "Overcast; a couple of morning thunderstorms around, then occasional rain and a thunderstorm",
        "PrecipitationProbability": 62,
        "ThunderstormProbability": 60,
        "RainProbability": 62,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 16.7,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 227,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 25.9,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 231,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "TotalLiquid": {
          "Value": 8.6,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 8.6,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 3,
        "HoursOfRain": 3,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 90
      },
      "Night": {
        "Icon": 12,
        "IconPhrase": "Showers",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Moderate",
        "ShortPhrase": "Overcast, showers",
        "LongPhrase": "Overcast, showers",
        "PrecipitationProbability": 87,
        "ThunderstormProbability": 29,
        "RainProbability": 87,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 11.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 227,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 20.4,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 230,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "TotalLiquid": {
          "Value": 10.7,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 10.7,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 6,
        "HoursOfRain": 6,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 97
      },
      "Sources": [
        "AccuWeather"
      ],
      "MobileLink": "http://m.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=2&unit=c&lang=en-us",
      "Link": "http://www.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=2&unit=c&lang=en-us"
    },
    {
      "Date": "2019-08-29T07:00:00+05:30",
      "EpochDate": 1567042200,
      "Sun": {
        "Rise": "2019-08-29T06:04:00+05:30",
        "EpochRise": 1567038840,
        "Set": "2019-08-29T18:19:00+05:30",
        "EpochSet": 1567082940
      },
      "Moon": {
        "Rise": "2019-08-29T04:45:00+05:30",
        "EpochRise": 1567034100,
        "Set": "2019-08-29T17:32:00+05:30",
        "EpochSet": 1567080120,
        "Phase": "WaningCrescent",
        "Age": 29
      },
      "Temperature": {
        "Minimum": {
          "Value": 25.7,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 27.9,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperature": {
        "Minimum": {
          "Value": 26.4,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 32.2,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperatureShade": {
        "Minimum": {
          "Value": 26.4,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 32.4,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "HoursOfSun": 1.4,
      "DegreeDaySummary": {
        "Heating": {
          "Value": 0,
          "Unit": "C",
          "UnitType": 17
        },
        "Cooling": {
          "Value": 9,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "AirAndPollen": [
        {
          "Name": "AirQuality",
          "Value": 0,
          "Category": "Good",
          "CategoryValue": 1,
          "Type": "Ozone"
        },
        {
          "Name": "Grass",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Mold",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Ragweed",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Tree",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "UVIndex",
          "Value": 4,
          "Category": "Moderate",
          "CategoryValue": 2
        }
      ],
      "Day": {
        "Icon": 12,
        "IconPhrase": "Showers",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Heavy",
        "ShortPhrase": "Cloudy, showers, some heavy",
        "LongPhrase": "Cloudy, showers, some heavy",
        "PrecipitationProbability": 81,
        "ThunderstormProbability": 29,
        "RainProbability": 81,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 16.7,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 231,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 24.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 234,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "TotalLiquid": {
          "Value": 21.5,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 21.5,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 4.5,
        "HoursOfRain": 4.5,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 98
      },
      "Night": {
        "Icon": 12,
        "IconPhrase": "Showers",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Heavy",
        "ShortPhrase": "Heavy showers late",
        "LongPhrase": "Plenty of clouds; a passing shower in the evening, then heavy showers",
        "PrecipitationProbability": 72,
        "ThunderstormProbability": 29,
        "RainProbability": 72,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 11.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 225,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 20.4,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 225,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "TotalLiquid": {
          "Value": 9.4,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 9.4,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 3.5,
        "HoursOfRain": 3.5,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 97
      },
      "Sources": [
        "AccuWeather"
      ],
      "MobileLink": "http://m.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=3&unit=c&lang=en-us",
      "Link": "http://www.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=3&unit=c&lang=en-us"
    },
    {
      "Date": "2019-08-30T07:00:00+05:30",
      "EpochDate": 1567128600,
      "Sun": {
        "Rise": "2019-08-30T06:03:00+05:30",
        "EpochRise": 1567125180,
        "Set": "2019-08-30T18:19:00+05:30",
        "EpochSet": 1567169340
      },
      "Moon": {
        "Rise": "2019-08-30T05:47:00+05:30",
        "EpochRise": 1567124220,
        "Set": "2019-08-30T18:28:00+05:30",
        "EpochSet": 1567169880,
        "Phase": "New",
        "Age": 0
      },
      "Temperature": {
        "Minimum": {
          "Value": 26,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 29,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperature": {
        "Minimum": {
          "Value": 27.8,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 34.8,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperatureShade": {
        "Minimum": {
          "Value": 27.8,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 32.9,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "HoursOfSun": 2.6,
      "DegreeDaySummary": {
        "Heating": {
          "Value": 0,
          "Unit": "C",
          "UnitType": 17
        },
        "Cooling": {
          "Value": 10,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "AirAndPollen": [
        {
          "Name": "AirQuality",
          "Value": 0,
          "Category": "Good",
          "CategoryValue": 1,
          "Type": "Ozone"
        },
        {
          "Name": "Grass",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Mold",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Ragweed",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Tree",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "UVIndex",
          "Value": 8,
          "Category": "Very High",
          "CategoryValue": 4
        }
      ],
      "Day": {
        "Icon": 12,
        "IconPhrase": "Showers",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Heavy",
        "ShortPhrase": "Heavy showers in the morning",
        "LongPhrase": "Considerable clouds; heavy showers in the morning, then a thunderstorm",
        "PrecipitationProbability": 76,
        "ThunderstormProbability": 60,
        "RainProbability": 76,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 14.8,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 238,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 24.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 247,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "TotalLiquid": {
          "Value": 15.6,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 15.6,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 4,
        "HoursOfRain": 4,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 88
      },
      "Night": {
        "Icon": 15,
        "IconPhrase": "Thunderstorms",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Light",
        "ShortPhrase": "A thunderstorm or two late",
        "LongPhrase": "Considerable clouds; a thunderstorm in spots in the evening, then a couple of thunderstorms around",
        "PrecipitationProbability": 62,
        "ThunderstormProbability": 60,
        "RainProbability": 62,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 14.8,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 237,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 22.2,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 241,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "TotalLiquid": {
          "Value": 6.4,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 6.4,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 2.5,
        "HoursOfRain": 2.5,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 95
      },
      "Sources": [
        "AccuWeather"
      ],
      "MobileLink": "http://m.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=4&unit=c&lang=en-us",
      "Link": "http://www.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=4&unit=c&lang=en-us"
    },
    {
      "Date": "2019-08-31T07:00:00+05:30",
      "EpochDate": 1567215000,
      "Sun": {
        "Rise": "2019-08-31T06:03:00+05:30",
        "EpochRise": 1567211580,
        "Set": "2019-08-31T18:19:00+05:30",
        "EpochSet": 1567255740
      },
      "Moon": {
        "Rise": "2019-08-31T06:46:00+05:30",
        "EpochRise": 1567214160,
        "Set": "2019-08-31T19:21:00+05:30",
        "EpochSet": 1567259460,
        "Phase": "WaxingCrescent",
        "Age": 1
      },
      "Temperature": {
        "Minimum": {
          "Value": 25.5,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 29,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperature": {
        "Minimum": {
          "Value": 28.1,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 33.2,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "RealFeelTemperatureShade": {
        "Minimum": {
          "Value": 28.1,
          "Unit": "C",
          "UnitType": 17
        },
        "Maximum": {
          "Value": 33.4,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "HoursOfSun": 2,
      "DegreeDaySummary": {
        "Heating": {
          "Value": 0,
          "Unit": "C",
          "UnitType": 17
        },
        "Cooling": {
          "Value": 9,
          "Unit": "C",
          "UnitType": 17
        }
      },
      "AirAndPollen": [
        {
          "Name": "AirQuality",
          "Value": 0,
          "Category": "Good",
          "CategoryValue": 1,
          "Type": "Ozone"
        },
        {
          "Name": "Grass",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Mold",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Ragweed",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "Tree",
          "Value": 0,
          "Category": "Low",
          "CategoryValue": 1
        },
        {
          "Name": "UVIndex",
          "Value": 4,
          "Category": "Moderate",
          "CategoryValue": 2
        }
      ],
      "Day": {
        "Icon": 15,
        "IconPhrase": "Thunderstorms",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Moderate",
        "ShortPhrase": "Clouds, a thunderstorm or two",
        "LongPhrase": "Considerable cloudiness, a couple of thunderstorms around",
        "PrecipitationProbability": 62,
        "ThunderstormProbability": 60,
        "RainProbability": 62,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 16.7,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 239,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 24.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 241,
            "Localized": "WSW",
            "English": "WSW"
          }
        },
        "TotalLiquid": {
          "Value": 9.3,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 9.3,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 4,
        "HoursOfRain": 4,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 93
      },
      "Night": {
        "Icon": 7,
        "IconPhrase": "Cloudy",
        "HasPrecipitation": "true",
        "PrecipitationType": "Rain",
        "PrecipitationIntensity": "Heavy",
        "ShortPhrase": "Cloudy, a thunderstorm",
        "LongPhrase": "Considerable cloudiness, a thunderstorm",
        "PrecipitationProbability": 54,
        "ThunderstormProbability": 60,
        "RainProbability": 54,
        "SnowProbability": 0,
        "IceProbability": 0,
        "Wind": {
          "Speed": {
            "Value": 11.1,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 210,
            "Localized": "SSW",
            "English": "SSW"
          }
        },
        "WindGust": {
          "Speed": {
            "Value": 20.4,
            "Unit": "km/h",
            "UnitType": 7
          },
          "Direction": {
            "Degrees": 226,
            "Localized": "SW",
            "English": "SW"
          }
        },
        "TotalLiquid": {
          "Value": 7.8,
          "Unit": "mm",
          "UnitType": 3
        },
        "Rain": {
          "Value": 7.8,
          "Unit": "mm",
          "UnitType": 3
        },
        "Snow": {
          "Value": 0,
          "Unit": "cm",
          "UnitType": 4
        },
        "Ice": {
          "Value": 0,
          "Unit": "mm",
          "UnitType": 3
        },
        "HoursOfPrecipitation": 1.5,
        "HoursOfRain": 1.5,
        "HoursOfSnow": 0,
        "HoursOfIce": 0,
        "CloudCover": 96
      },
      "Sources": [
        "AccuWeather"
      ],
      "MobileLink": "http://m.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=5&unit=c&lang=en-us",
      "Link": "http://www.accuweather.com/en/lk/colombo/311399/daily-weather-forecast/311399?day=5&unit=c&lang=en-us"
    }
  ]
}


res_city = [
  {
    "Version": 1,
    "Key": "311399",
    "Type": "City",
    "Rank": 30,
    "LocalizedName": "Colombo",
    "EnglishName": "Colombo",
    "PrimaryPostalCode": "",
    "Region": {
      "ID": "ASI",
      "LocalizedName": "Asia",
      "EnglishName": "Asia"
    },
    "Country": {
      "ID": "LK",
      "LocalizedName": "Sri Lanka",
      "EnglishName": "Sri Lanka"
    },
    "AdministrativeArea": {
      "ID": "1",
      "LocalizedName": "Western",
      "EnglishName": "Western",
      "Level": 1,
      "LocalizedType": "Province",
      "EnglishType": "Province",
      "CountryID": "LK"
    },
    "TimeZone": {
      "Code": "IST",
      "Name": "Asia/Colombo",
      "GmtOffset": 5.5,
      "IsDaylightSaving": "false",
      "NextOffsetChange": "null"
    },
    "GeoPosition": {
      "Latitude": 6.927,
      "Longitude": 79.872,
      "Elevation": {
        "Metric": {
          "Value": 12,
          "Unit": "m",
          "UnitType": 5
        },
        "Imperial": {
          "Value": 39,
          "Unit": "ft",
          "UnitType": 0
        }
      }
    },
    "IsAlias": "false",
    "SupplementalAdminAreas": [],
    "DataSets": [],
    "Details": {
      "Key": "311399",
      "StationCode": "CECO",
      "StationGmtOffset": 5.5,
      "BandMap": "ASIA",
      "Climo": "VCCC",
      "LocalRadar": "",
      "MediaRegion": "null",
      "Metar": "VCBI",
      "NXMetro": "",
      "NXState": "",
      "Population": 642163,
      "PrimaryWarningCountyCode": "",
      "PrimaryWarningZoneCode": "",
      "Satellite": "INDIA",
      "Synoptic": "43467",
      "MarineStation": "",
      "MarineStationGMTOffset": "null",
      "VideoCode": "",
      "LocationStem": "lk/colombo/311399",
      "PartnerID": "null",
      "Sources": [
        {
          "DataType": "CurrentConditions",
          "Source": "AccuWeather",
          "SourceId": 1
        },
        {
          "DataType": "DailyForecast",
          "Source": "AccuWeather",
          "SourceId": 1
        },
        {
          "DataType": "Dangerous Thunderstorm Alert Push Notifications",
          "Source": "Earth Networks",
          "SourceId": 57
        },
        {
          "DataType": "HourlyForecast",
          "Source": "AccuWeather",
          "SourceId": 1
        }
      ],
      "CanonicalPostalCode": "",
      "CanonicalLocationKey": "311399"
    }
  }
]

string = json.dumps(response, indent=4)
dict_obj = json.loads(string)
#print(dict_obj)
#print("Type of dict_obj", type(dict_obj))

#print("DailyForecasts",  dict_obj.get('DailyForecasts'))

#print("Type of dict_obj DailyForecasts", type( dict_obj.get('DailyForecasts')))


string_city = json.dumps(res_city, indent=4)
dict_obj_city = json.loads(string_city)

#print(dict_obj_city)

#print("Type of dict_obj_city", type(dict_obj_city))

for city_item in dict_obj_city:
	lat = city_item.get('GeoPosition').get('Latitude')
	lng = city_item.get('GeoPosition').get('Longitude')
	city = city_item.get('EnglishName')
	#print(lat,lng,city)

#print("Type of city_item", type(city_item))
ndvi_ne = lat
ndvi_nw = lat
ndvi_se = lng
ndvi_sw = lng

#print("Type of geoposition", type(geoposition))

L = dict_obj.get('DailyForecasts')

#print(L)

import os

cur = dir(os)
count = 1
for i in cur:
    count += 1
   # print(count,i)
content_obj = []

for l in L:
	dic_w_obj={}
	date = parse(l['Date'])
	dt = date.date().strftime("%m/%d/%Y")
	wkdt = parse((date.date()).strftime("%m/%d/%Y"))
	yr = wkdt.year
	weekofyr= wkdt.isocalendar()[1]
	dic_w_obj["id"]= count
	dic_w_obj["city"]=city
	dic_w_obj["year"] = yr
	dic_w_obj["weekofyear"] = weekofyr
	dic_w_obj["week_start_date"] = dt
	dic_w_obj["ndvi_ne"] = ndvi_ne
	dic_w_obj["ndvi_nw"] = ndvi_nw
	dic_w_obj["ndvi_se"] = ndvi_se
	dic_w_obj["ndvi_sw"] = ndvi_sw
	dic_w_obj["precipitation_amt_mm"]=float(l['Day']['Rain']['Value'])
	dic_w_obj["reanalysis_air_temp_k"] = l['Temperature']['Maximum']['Value'] +  273.15
	dic_w_obj["reanalysis_avg_temp_k"] = float(((float(l['RealFeelTemperature']['Maximum']['Value']) + 273.15) + (float(l['RealFeelTemperature']['Minimum']['Value']) + 273.15))/2)
	dic_w_obj["reanalysis_dew_point_temp_k"] =float(l['DegreeDaySummary']['Cooling']['Value']) + 273.15
	dic_w_obj["reanalysis_max_air_temp_k"] =float(l['RealFeelTemperature']['Maximum']['Value']) + 273.15
	dic_w_obj["reanalysis_min_air_temp_k"] =float(l['RealFeelTemperature']['Minimum']['Value']) + 273.15
	dic_w_obj["reanalysis_precip_amt_kg_per_m2"] = float(l['Night']['PrecipitationProbability'])
	dic_w_obj["reanalysis_relative_humidity_percent"] =float(l['Day']['PrecipitationProbability'])
	dic_w_obj["reanalysis_sat_precip_amt_mm"] = float(l['Day']['TotalLiquid']['Value'])
	dic_w_obj["reanalysis_specific_humidity_g_per_kg"] = float(l['Night']['PrecipitationProbability'])
	dic_w_obj["reanalysis_tdtr_k"] = float(l['RealFeelTemperature']['Maximum']['Value'])  - float(l['RealFeelTemperature']['Minimum']['Value']) 
	dic_w_obj["station_avg_temp_c"]= (float(l['Temperature']['Maximum']['Value']) + float(l['Temperature']['Minimum']['Value']))/2
	dic_w_obj["station_diur_temp_rng_c"] = float(l['Temperature']['Maximum']['Value']) - float(l['Temperature']['Minimum']['Value'])
	dic_w_obj["station_max_temp_c"] = float(l['Temperature']['Maximum']['Value'])
	dic_w_obj["station_min_temp_c"] = float(l['Temperature']['Minimum']['Value']) 
	dic_w_obj["station_precip_mm"] = float(l['Day']['Rain']['Value'])
	#print(dic_w_obj)
	content_obj.append(dic_w_obj)
json_obj = json.dumps(content_obj)
#print(content_obj)
#dict_s_date = {}

s_date= L[0].get('Date')
#print("Type of dict_obj  L[0]", type( L[0]))
#print(s_date)

dt = parse(s_date)
#week start date
wk_st_dt = parse((dt.date()).strftime("%m/%d/%Y"))

# #year
# yr = wk_st_dt.year
		
# #start_date = decoded['Headline']['EffectiveDate']

# #week of year
# weekofyr= wk_st_dt.isocalendar()[1]



r = requests.post('http://127.0.0.1:12334/predict',json=content_obj)
#print(content_obj)
