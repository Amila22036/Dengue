import requests
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import json
from decimal import Decimal
from dateutil.parser import parse


#url_colombo = 'http://dataservice.accuweather.com/forecasts/v1/daily/5day/311399?apikey=W13g0DmUf6BbxnYDkG1mRmITeCGSBtiJ&metric=true'



response = requests.get(url_colombo)
print(response.status_code)
decoded = json.loads(response.text)
start_date = decoded['Headline']['EffectiveDate']


dt = parse(start_date)
#week start date
wk_st_dt = parse((dt.date()).strftime("%m/%d/%Y"))

#year
yr = wk_st_dt.year

#week of year
weekofyr= wk_st_dt.isocalendar()[1]
precipitation_amt = float(decoded['DailyForecasts']['Day']['Rain']['Value'])
reanalysis_air_temp = float(decoded['DailyForecasts']['Temperature']['Maximum']['Value']) +  273.15
reanalysis_avg_temp = float((reanalysis_max_air_temp_k + reanalysis_min_air_temp_k)/2)
reanalysis_dew_point_temp =float(decoded['DailyForecasts']['DegreeDaySummary']['Cooling']['Value']) + 273.15
reanalysis_max_air_temp =float(decoded['DailyForecasts']['RealFeelTemperature']['Maximum']['Value']) + 273.15
reanalysis_min_air_temp =float(decoded['DailyForecasts']['RealFeelTemperature']['Minimum']['Value']) + 273.15
reanalysis_precip_amt = float(decoded['DailyForecasts']['Night']['PrecipitationProbability'])
reanalysis_relative_humidity =float(decoded['DailyForecasts']['Day']['PrecipitationProbability'])
reanalysis_sat_precip_amt = float(decoded['DailyForecasts']['Day']['TotalLiquid']['Value'])
reanalysis_specific_humidity = float(decoded['DailyForecasts']['Night']['PrecipitationProbability'])
reanalysis_tdtr = reanalysis_max_air_temp - reanalysis_min_air_temp
station_avg_temp= (station_max_temp - station_min_temp)/2
station_diur_temp_rng = station_max_temp - station_min_temp
station_max_temp = float(decoded['DailyForecasts']['Temperature']['Maximum']['Value'])
station_min_temp = float(decoded['DailyForecasts']['Temperature']['Minimum']['Value']) 
station_precip = float(decoded['DailyForecasts']['Day']['Rain']['Value'])



#url_locat_colombo =  'http://dataservice.accuweather.com/locations/v1/cities/LK/search?apikey=W13g0DmUf6BbxnYDkG1mRmITeCGSBtiJ&q='+city+'&details=true&alias=western'

city = 'colombo'

response_loca = requests.get(url_locat_colombo)
print(response_loca.status_code)
decoded_loca = json.loads(response_loca.text)

lat = decoded_loca['GeoPosition']['Latitude']
ndvi_ne = float(lat)
ndvi_nw = float(lat)
long = decoded_loca['GeoPosition']['Longitude']
ndvi_se = float(long)
ndvi_sw = float(long)

import os

cur = dir(os)
count = 1
for i in cur:
    count += 1
   # print(count,i)


rec = {
       "id": "'+i+'",
       "city": "'+city+'",
       "year": "'+yr+'",
       "weekofyear": "'+weekofyr+'",
       "week_start_date": "'+wk_st_dt+'",
       "ndvi_ne": "'+ndvi_ne+'",
       "ndvi_nw":"'+ndvi_nw+'",
       "ndvi_se":"'+ndvi_se+'",
       "ndvi_sw":"'+ndvi_sw+'",
       "precipitation_amt_mm": "'+precipitation_amt+'",
       "reanalysis_air_temp_k": "'+reanalysis_air_temp+'",
       "reanalysis_avg_temp_k": "'+reanalysis_avg_temp+'",
       "reanalysis_dew_point_temp_k": "'+reanalysis_dew_point_temp+'",
       "reanalysis_max_air_temp_k": "'+reanalysis_max_air_temp+'",
       "reanalysis_min_air_temp_k":"'+reanalysis_min_air_temp+'",
       "reanalysis_precip_amt_kg_per_m2":"'+reanalysis_precip_amt+'",
       "reanalysis_relative_humidity_percent":"'+reanalysis_relative_humidity+'",
       "reanalysis_sat_precip_amt_mm":"'+reanalysis_sat_precip_amt+'",
       "reanalysis_specific_humidity_g_per_kg": "'++'",
       "reanalysis_tdtr_k": "'+reanalysis_specific_humidity+'",
       "station_avg_temp_c": "'+station_avg_temp+'",
       "station_diur_temp_rng_c": "'+station_diur_temp_rng+'",
       "station_max_temp_c": "'+station_max_temp+'",
       "station_min_temp_c": "'+station_min_temp+'",
       "station_precip_mm": "'+station_precip+'"
    }

# rec =[{
    # "id": 1256,
    # "city": "sj",
    # "year": 2006,
    # "weekofyear": 24,
    # "week_start_date": "6/18/2006",
    # "ndvi_ne": -2.01003333,
    # "ndvi_nw": -2.01003333,
    # "ndvi_se": -1.1517,
    # "ndvi_sw": -1.1498833,
    # "precipitation_amt_mm": 7.56,
    # "reanalysis_air_temp_k": 301.0214286,
    # "reanalysis_avg_temp_k": 301.1428571,
    # "reanalysis_dew_point_temp_k": 296.3614286,
    # "reanalysis_max_air_temp_k": 303.3,
    # "reanalysis_min_air_temp_k": 299.6,
    # "reanalysis_precip_amt_kg_per_m2": 12.4,
    # "reanalysis_relative_humidity_percent": 75.92,
    # "reanalysis_sat_precip_amt_mm": 7.56,
    # "reanalysis_specific_humidity_g_per_kg": 17.78428571,
    # "reanalysis_tdtr_k": 2.742857143,
    # "station_avg_temp_c": 28.94285714,
    # "station_diur_temp_rng_c": 7.671428571,
    # "station_max_temp_c": 34.4,
    # "station_min_temp_c": 23.3,
    # "station_precip_mm": 34,
	# "lat" : -2.01003333,
	# "log": -1.1498833

  # },
  # {
    # "id": 1257,
    # "city": "sj",
    # "year": 2006,
    # "weekofyear": 25,
    # "week_start_date": "6/25/2006",
    # "ndvi_ne": 0.0255,
    # "ndvi_nw": 0.04276667,
    # "ndvi_se": 0.1070429,
    # "ndvi_sw": 0.1105571,
    # "precipitation_amt_mm": 19.95,
    # "reanalysis_air_temp_k": 300.4785714,
    # "reanalysis_avg_temp_k": 300.5357143,
    # "reanalysis_dew_point_temp_k": 296.6428571,
    # "reanalysis_max_air_temp_k": 302.4,
    # "reanalysis_min_air_temp_k": 298.7,
    # "reanalysis_precip_amt_kg_per_m2": 39.52,
    # "reanalysis_relative_humidity_percent": 79.69571429,
    # "reanalysis_sat_precip_amt_mm": 19.95,
    # "reanalysis_specific_humidity_g_per_kg": 18.09142857,
    # "reanalysis_tdtr_k": 2.814285714,
    # "station_avg_temp_c": 28.07142857,
    # "station_diur_temp_rng_c": 6.757142857,
    # "station_max_temp_c": 33.3,
    # "station_min_temp_c": 23.9,
    # "station_precip_mm": 25.5,
	# "lat" : -2.01003333,
	# "log" : -1.1498833
  # },
  # {
    # "id": 1258,
    # "city": "sj",
    # "year": 2006,
    # "weekofyear": 26,
    # "week_start_date": "7/2/2006",
    # "ndvi_ne": 1.1035,
    # "ndvi_nw": 1.1977,
    # "ndvi_se": 1.1338714,
    # "ndvi_sw": 1.1229429,
    # "precipitation_amt_mm": 111.15,
    # "reanalysis_air_temp_k": 300.5042857,
    # "reanalysis_avg_temp_k": 300.6357143,
    # "reanalysis_dew_point_temp_k": 297.1614286,
    # "reanalysis_max_air_temp_k": 303,
    # "reanalysis_min_air_temp_k": 299,
    # "reanalysis_precip_amt_kg_per_m2": 38.37,
    # "reanalysis_relative_humidity_percent": 82.16,
    # "reanalysis_sat_precip_amt_mm": 111.15,
    # "reanalysis_specific_humidity_g_per_kg": 18.67142857,
    # "reanalysis_tdtr_k": 2.242857143,
    # "station_avg_temp_c": 27.87142857,
    # "station_diur_temp_rng_c": 6.814285714,
    # "station_max_temp_c": 33.3,
    # "station_min_temp_c": 22.8,
    # "station_precip_mm": 58.2,
	# "lat" : -2.01003333,
	# "log" : -1.1498833
  # }]

r = requests.post('http://127.0.0.1:12334/predict',json=rec)
print(r.text)

